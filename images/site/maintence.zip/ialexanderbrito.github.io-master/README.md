# PORTFÓLIO

### PAGE
#### HOME PAGE
[![](https://raw.githubusercontent.com/ialexanderbrito/ialexanderbrito.github.io/master/images/home.png)](http://ialexanderbrito.tk)

> ##### Nota: Ao clicar na imagem você será redirecionado para o site.

#### ERRO 404
[![](https://raw.githubusercontent.com/ialexanderbrito/ialexanderbrito.github.io/master/images/404.png)](http://ialexanderbrito.tk)

> ##### Nota: Ao clicar na imagem você será redirecionado para o site.

### SOCIAIS
[![](http://icons.iconarchive.com/icons/lunartemplates/modern-social-media-circles/64/Facebook-icon.png)](https://facebook.com/iAlexanderBrito)
[![](http://icons.iconarchive.com/icons/lunartemplates/modern-social-media-circles/64/Twitter-icon.png)](https://twitter.com/iAlexanderBrito)
[![](http://icons.iconarchive.com/icons/lunartemplates/modern-social-media-circles/64/Instagram-icon.png)](https://instagram.com/ialexanderbrito)
[![](http://icons.iconarchive.com/icons/lunartemplates/modern-social-media-circles/64/GitHub-icon.png)](http://github.com/ialexanderbrito)
[![](http://icons.iconarchive.com/icons/lunartemplates/modern-social-media-circles/64/LinkedIn-icon.png)](https://www.linkedin.com/in/ialexanderbrito/)

> Obrigado.
